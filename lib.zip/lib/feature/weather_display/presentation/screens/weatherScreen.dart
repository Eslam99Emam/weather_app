import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:weather_app/feature/weather_display/presentation/providers/Location_Providing_Notifiers.dart';
import 'package:weather_app/feature/weather_display/presentation/providers/Weather_Providing_Notifiers.dart';

import '../providers/Coordinates_Providing_Notifiers.dart';
import '../providers/location_Notifier.dart';
import '../providers/location_Providers.dart';

class Weatherscreen extends ConsumerWidget {
  const Weatherscreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    log("Weather Screen");
    var location = ref.watch(locationProvidingNotifier);
    log("${location!.location.country}");
    var weather = ref.watch(weatherProvidingNotifier);
    log("${weather!.tempreture} ${weather.image}");
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          ref.read(locationProvider(LocationNotifierParams(ref.read(coordinatesProvidingNotifier)!, "Germany")));
        },
        child: Icon(Icons.add),
      ),
      key: ValueKey("done"),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(
            "${location.location.country}",
            style: Theme.of(context).textTheme.displayLarge,
          ),
        ],
      ),
    );
  }
}
