import 'package:geocoding/geocoding.dart';

class Location {
  Placemark location;

  Location({required this.location});
}
