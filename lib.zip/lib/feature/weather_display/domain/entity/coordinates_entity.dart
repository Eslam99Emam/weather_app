
class Coordinates {
  double lat;
  double lon;

  Coordinates({required this.lat, required this.lon});
}
