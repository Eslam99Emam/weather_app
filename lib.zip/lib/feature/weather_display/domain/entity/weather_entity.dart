class Weather {
  double tempreture;
  String image;

  Weather({required this.tempreture, required this.image});
}
